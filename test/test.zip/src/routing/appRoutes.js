export const AppRoutes = {
  HOME: '/',
  SERIES: '/series',
  MOVIES: '/movies',
};
