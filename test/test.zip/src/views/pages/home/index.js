import HomeComponent from '../../components/HomeComponent';
const Home = () => {
  return (
    <div className='wrapper'>
      <HomeComponent />
    </div>
  );
};

export default Home;
