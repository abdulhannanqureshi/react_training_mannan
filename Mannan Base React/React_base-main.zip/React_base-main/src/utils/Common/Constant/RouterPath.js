export const USER_ROUTES = {
  USER_PATH: '/user',
  EDIT_USER_PATH: '/user/edit'
}

export const CANVAS_ROUTES = {
  CANVAS_PATH: '/canvas'
}