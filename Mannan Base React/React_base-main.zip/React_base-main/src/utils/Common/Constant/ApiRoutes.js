export const UserAPI = {
  USERS_API: 'users'
}