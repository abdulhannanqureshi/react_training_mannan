

export const customAction = (state, dispatch) => ({
  custom: data => {
    dispatch({ type: 'IYI', payload: 'Eartugrul Gazi' })
  }
})