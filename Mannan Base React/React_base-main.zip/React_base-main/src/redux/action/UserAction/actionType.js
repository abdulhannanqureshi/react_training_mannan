export const UserActionType = {
  USERS: 'USERS',
  DELETE: 'DELETE',
  DETAIL: 'DETAIL',
  UPDATE_DETAIL: 'UPDATE_DETAIL'
}