import React from 'react'
import CanvasComponent from 'components/canvas'

const Canvas = props => <CanvasComponent {...props} />

export default Canvas