import React from 'react'
import UserList from 'components/users/UserList'

const Users = (props) => <UserList {...props} />;

export default Users;