import React from 'react'
import Edit from 'components/users/EditUser'

const EditUser = props => <Edit {...props} />

export default EditUser